/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Reuniao {
    private String id;
    private String nome;
    private Date data;
    private ArrayList participantes;
    private boolean publica;
    private String link;
    private String local;
    private String ata;
    private String senha;

    public Reuniao(String id,String nome,String data, ArrayList participantes, boolean publica, String link, String local, String ata) {
        this.nome = nome;
        this.id = id;
        try {
            this.data = new SimpleDateFormat("dd/MM/yyyy").parse(data);
        } catch (ParseException ex) {
            Logger.getLogger(Reuniao.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.participantes = participantes;
        this.publica = publica;
        this.link = link;
        this.local = local;
        this.ata = ata;
    }

    public Reuniao() {
    }
    
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the senha
     */
    public String getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setSenha(String id) {
        this.id= id;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public ArrayList getParticipantes() {
        return participantes;
    }

    public void setParticipantes(ArrayList participantes) {
        this.participantes = participantes;
    }

    

    public boolean isPublica() {
        return publica;
    }

    public void setPublica(boolean publica) {
        this.publica = publica;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getLocal() {
        return local;
    }

    public void setLocal(String local) {
        this.local = local;
    }

    @Override
    public String toString() {
        return "Reuniao{" + "nome=" + nome + "senha=" + senha + "data=" + data + ", participantes=" + participantes + ", publica=" + publica + ", link=" + link + ", local=" + local + '}';
    }

    public void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
    
    
}
