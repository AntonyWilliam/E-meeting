
package modelo;
import modelo.Reuniao;
import java.util.ArrayList;

public final class ListaReuniao {
    private static ArrayList<Reuniao> reuniao = new ArrayList<>();
   
    public static ArrayList<Reuniao> getReuniao(){
        return reuniao;
         
    }
    public static ArrayList<Reuniao> addReuniao(Reuniao reuniao){
        return reuniao.add();
    }
}
